#ifndef CXGB3I_TRANSPORT
#define CXGB3I_TRANSPORT

struct iscsi_conn;

extern void cxgb3i_create_conn(struct iscsi_conn *conn);

#endif
